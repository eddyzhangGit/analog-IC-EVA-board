//
//  SerialPortDemoController.swift
//  ORSSerialPortSwiftDemo
//
//  Created by Andrew Madsen on 10/31/14.
//  Copyright (c) 2014 Open Reel Software. All rights reserved.
//
//	Permission is hereby granted, free of charge, to any person obtaining a
//	copy of this software and associated documentation files (the
//	"Software"), to deal in the Software without restriction, including
//	without limitation the rights to use, copy, modify, merge, publish,
//	distribute, sublicense, and/or sell copies of the Software, and to
//	permit persons to whom the Software is furnished to do so, subject to
//	the following conditions:
//	
//	The above copyright notice and this permission notice shall be included
//	in all copies or substantial portions of the Software.
//	
//	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
//	OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
//	MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
//	IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
//	CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
//	TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
//	SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

import Cocoa

class StringWrapper: NSObject {
    var str: String
    init(str: String) {
        self.str = str
    }
}


extension String {
    
    var length: Int {
        return self.characters.count
    }
    
    subscript (i: Int) -> String {
        return self[Range(i ..< i + 1)]
    }
    
    func substring(from: Int) -> String {
        return self[Range(min(from, length) ..< length)]
    }
    
    func substring(to: Int) -> String {
        return self[Range(0 ..< max(0, to))]
    }
    
    subscript (r: Range<Int>) -> String {
        let range = Range(uncheckedBounds: (lower: max(0, min(length, r.lowerBound)),
                                            upper: min(length, max(0, r.upperBound))))
        let start = index(startIndex, offsetBy: range.lowerBound)
        let end = index(start, offsetBy: range.upperBound - range.lowerBound)
        return self[Range(start ..< end)]
    }
    
}



class SerialPortDemoController: NSObject, ORSSerialPortDelegate, NSUserNotificationCenterDelegate {
	
	let serialPortManager = ORSSerialPortManager.shared()
	let availableBaudRates = [300, 1200, 2400, 4800, 9600, 14400, 19200, 28800, 38400, 57600, 115200, 230400]
	var shouldAddLineEnding = false
    var bind_check = "ff"
    var parameterId: StringWrapper = StringWrapper(str: "One")
    
    
    let DAC_ref = 3.0
    let ADC_ref = 4.0
    let R_sense_low = 0.68
    let R_sense_high = 0.16

	var serialPort: ORSSerialPort? {
		didSet {
			oldValue?.close()
			oldValue?.delegate = nil
			serialPort?.delegate = self
		}
	}
	
	@IBOutlet weak var sendTextField: NSTextField!
	@IBOutlet var receivedDataTextView: NSTextView!
	@IBOutlet weak var openCloseButton: NSButton!
	@IBOutlet weak var lineEndingPopUpButton: NSPopUpButton!
	var lineEndingString: String {
		let map = [0: "\r", 1: "\n", 2: "\r\n"]
		if let result = map[self.lineEndingPopUpButton.selectedTag()] {
			return result
		} else {
			return "\n"
		}
	}
	
	override init() {
		super.init()
		
		let nc = NotificationCenter.default
		nc.addObserver(self, selector: #selector(serialPortsWereConnected(_:)), name: NSNotification.Name.ORSSerialPortsWereConnected, object: nil)
		nc.addObserver(self, selector: #selector(serialPortsWereDisconnected(_:)), name: NSNotification.Name.ORSSerialPortsWereDisconnected, object: nil)
		
		NSUserNotificationCenter.default.delegate = self
	}
	
	deinit {
		NotificationCenter.default.removeObserver(self)
	}
	


	@IBAction func send(_: AnyObject) {
		var string = self.sendTextField.stringValue
		if self.shouldAddLineEnding && !string.hasSuffix("\n") {
			string += self.lineEndingString
		}
        string +=  "\r\n"

		if let data = string.data(using: String.Encoding.utf8) {
			self.serialPort?.send(data)
		}
	}
	
	@IBAction func openOrClosePort(_ sender: AnyObject) {
		if let port = self.serialPort {
			if (port.isOpen) {
				port.close()
			} else {
				port.open()
				self.receivedDataTextView.textStorage?.mutableString.setString("");
			}
		}
	}
	
	// MARK: - ORSSerialPortDelegate
	
	func serialPortWasOpened(_ serialPort: ORSSerialPort) {
		self.openCloseButton.title = "Close"
	}
	
	func serialPortWasClosed(_ serialPort: ORSSerialPort) {
		self.openCloseButton.title = "Open"
	}
	
	func serialPort(_ serialPort: ORSSerialPort, didReceive data: Data) {
		if let string = NSString(data: data, encoding: String.Encoding.utf8.rawValue) {
            
			self.receivedDataTextView.textStorage?.mutableString.append(string as String)
			self.receivedDataTextView.needsDisplay = true
            
            //Input Parsing
            //2 kind of input, ADC, or GPIO
            let in_data = String(string)

            if(in_data[0] == "A")
            {
                let ADC_num = Int(in_data[1 ..< 3])
                let ADC_data_raw = Double(in_data[4 ..< 10])
                
                //1 if statement for each ADC
                //There are 3 different kind of ADCs
                //1) Power voltage
                //2)Power current
                //3)Bias current
                
                //etc, for 1) Power voltage reading
                //Thera are 7 Power supply Voltages
                //There are 6 power supply Current
                //There are 4 bais current curreny
                
                if (ADC_num! == 2)
                {
                    //Convert to voltage
                    let ADC_voltage = ADC_data_raw!/16384.0 * ADC_ref
                    //Update the voltage reading
                    P1_voltage.title = String(format:"%.3f", ADC_voltage)
                    
                }
                
                //etc, 2) for Power current reading
                if (ADC_num! == 3)
                {
                    //Convert to voltage
                    let ADC_voltage = ADC_data_raw!/16384.0 * ADC_ref
                    
                    //Convert to current = ADC/Gain/R_sense
                    let current = ADC_voltage/100.0/R_sense_low
                    
                    //Update the current reading in mA
                    P1_current.title = String(format:"%.3f", current * 1000)
                }
    
                //etc, 3)for Bais current reading
                
                if (ADC_num! == 21)
                {
                    //Convert to voltage
                    let ADC_voltage = ADC_data_raw!/16384.0 * ADC_ref
                    
                    //Convert to current = ADC/Gain/R_sense
                    //Gain = 1.0+95.3/4.99
                    let current = ADC_voltage/(1.0+95.3/4.99)/200.0
                    
                    //Update the current reading in uA
                    BC1_text.title = String(format:"%.1f", current * 1000000.0)
                }
                
                if (ADC_num! == 22)
                {
                    //Convert to voltage
                    let ADC_voltage = ADC_data_raw!/16384.0 * ADC_ref
                    
                    //Convert to current = ADC/Gain/R_sense
                    //Gain = 1.0+95.3/4.99
                    let current = ADC_voltage/(1.0+95.3/4.99)/200.0
                    
                    //Update the current reading in uA
                    BC2_text.title = String(format:"%.1f", current * 1000000.0)
                }
                
            }
            else
            {
                //This is Digital
                //Log into file
                
            }
            
            
		}
        
	}
	
	func serialPortWasRemovedFromSystem(_ serialPort: ORSSerialPort) {
		self.serialPort = nil
		self.openCloseButton.title = "Open"
	}
	
	func serialPort(_ serialPort: ORSSerialPort, didEncounterError error: Error) {
		print("SerialPort \(serialPort) encountered an error: \(error)")
	}
	
	// MARK: - NSUserNotifcationCenterDelegate
	
	func userNotificationCenter(_ center: NSUserNotificationCenter, didDeliver notification: NSUserNotification) {
		let popTime = DispatchTime.now() + Double(Int64(3.0 * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC)
		DispatchQueue.main.asyncAfter(deadline: popTime) { () -> Void in
			center.removeDeliveredNotification(notification)
		}
	}
	
	func userNotificationCenter(_ center: NSUserNotificationCenter, shouldPresent notification: NSUserNotification) -> Bool {
		return true
	}
	
	// MARK: - Notifications
	
	func serialPortsWereConnected(_ notification: Notification) {
		if let userInfo = notification.userInfo {
			let connectedPorts = userInfo[ORSConnectedSerialPortsKey] as! [ORSSerialPort]
			print("Ports were connected: \(connectedPorts)")
			self.postUserNotificationForConnectedPorts(connectedPorts)
		}
	}
	
	func serialPortsWereDisconnected(_ notification: Notification) {
		if let userInfo = notification.userInfo {
			let disconnectedPorts: [ORSSerialPort] = userInfo[ORSDisconnectedSerialPortsKey] as! [ORSSerialPort]
			print("Ports were disconnected: \(disconnectedPorts)")
			self.postUserNotificationForDisconnectedPorts(disconnectedPorts)
		}
	}
	
	func postUserNotificationForConnectedPorts(_ connectedPorts: [ORSSerialPort]) {
		let unc = NSUserNotificationCenter.default
		for port in connectedPorts {
			let userNote = NSUserNotification()
			userNote.title = NSLocalizedString("Serial Port Connected", comment: "Serial Port Connected")
			userNote.informativeText = "Serial Port \(port.name) was connected to your Mac."
			userNote.soundName = nil;
			unc.deliver(userNote)
		}
	}
	
	func postUserNotificationForDisconnectedPorts(_ disconnectedPorts: [ORSSerialPort]) {
		let unc = NSUserNotificationCenter.default
		for port in disconnectedPorts {
			let userNote = NSUserNotification()
			userNote.title = NSLocalizedString("Serial Port Disconnected", comment: "Serial Port Disconnected")
			userNote.informativeText = "Serial Port \(port.name) was disconnected from your Mac."
			userNote.soundName = nil;
			unc.deliver(userNote)
		}
	}
    
    //Variable Resistor Start
    
    @IBOutlet weak var slidebar_2k5: NSSliderCell!
    @IBOutlet weak var slidebar_10k: NSSliderCell!
    
    @IBOutlet weak var text_2k5: NSTextFieldCell!
    @IBOutlet weak var text_10k: NSTextFieldCell!
    
    @IBAction func set_2k5(_ sender: Any) {
        
        let slidebar_value = slidebar_2k5.integerValue
        //Calculate the expected resistance
        text_2k5.title = String(Int(slidebar_2k5.doubleValue / 256 * 2500))
        
        //Creat message string
        var string = ""
        
        //Formating the Message
        string += "P"  //POT Identified
        string += "1"  //POT Chip ID 1-8
        string += "2"  //POT Channel 1-2
        //Add the value
        string += String(format:"%02X",slidebar_value)
        //End of the message
        string +=  "\r\n"
        //Log this message to the window
        self.receivedDataTextView.textStorage?.mutableString.append(string as String)
        self.receivedDataTextView.needsDisplay = true
        
        
        //Sets the text
        /*if let data = string.data(using: String.Encoding.utf8) {
            self.serialPort?.send(data)
        }
        */
        
        
    }
    
    @IBAction func set_10k(_ sender: NSButtonCell) {
        
        let slidebar_value = slidebar_10k.integerValue
        //Calculate the expected resistance
        text_10k.title = String(Int(slidebar_10k.doubleValue / 256 * 2500))
        
        //Creat message string
        var string = ""
        
        //Formating the Message
        string += "P"  //POT Identified
        string += "1"  //POT Chip ID 1-8
        string += "2"  //POT Channel 1-2
        //Add the value
        string += String(format:"%02X",slidebar_value)
        //End of the message
        string +=  "\r\n"
        
        //Log this message to the window
        self.receivedDataTextView.textStorage?.mutableString.append(string as String)
        self.receivedDataTextView.needsDisplay = true
        
        
        //Sets the text
        /*if let data = string.data(using: String.Encoding.utf8) {
         self.serialPort?.send(data)
         }
         */
    }
    //Variable Resistor end
    
    
    //Voltge Supply Start

    @IBOutlet weak var P1_input: NSTextFieldCell!
    
    
    @IBOutlet weak var P1_voltage: NSTextFieldCell!
    
    @IBOutlet weak var P1_current: NSTextFieldCell!
    
    @IBAction func P1_set(_ sender: NSButtonCell) {
        
        let voltage = Double(P1_input.title)
        
        let R1 = (voltage!/0.5 - 1.0) * 500.0
        
        //R1 = R1 * 500.0
        let slidebar_value = R1/2500.0 * 255.0
        //Creat message string
        var string = ""
        
        //Formating the Message
        string += "P"  //POT Identified
        string += "1"  //POT Chip ID 1-8
        string += "2"  //POT Channel 1-2
        //Add the value
        string += String(format:"%02X",Int(slidebar_value))
        //End of the message
        string +=  "\r\n"
        //Log this message to the window
        self.receivedDataTextView.textStorage?.mutableString.append(string as String)
        self.receivedDataTextView.needsDisplay = true
        
        
        //Sets the text
        /*if let data = string.data(using: String.Encoding.utf8) {
         self.serialPort?.send(data)
         }
         */
    }
    //Voltage Supply End
    

    //Bias Voltage  Start
    @IBOutlet weak var BV1_input: NSTextFieldCell!
    @IBOutlet weak var BV1_text: NSTextFieldCell!

    @IBOutlet weak var BV2_input: NSTextFieldCell!
    
    @IBOutlet weak var BV2_text: NSTextFieldCell!
    
    
    @IBOutlet weak var BC1_input: NSTextFieldCell!
    @IBOutlet weak var BC1_text: NSTextFieldCell!
    @IBOutlet weak var BC2_input: NSTextFieldCell!
    
    @IBOutlet weak var BC2_text: NSTextFieldCell!
    
    @IBAction func BV1_set(_ sender: NSButtonCell) {
        
        BV1_text.title = BV1_input.title
        
        let input = Double(BV1_input.title)
        let Code = input!/DAC_ref * 65535
        //Creat message string
        var string = ""
        
        //Formating the Message
        string += "D"  //DAC Identified
        string += "1"  //DAC ID 1-3
        string += "1"  //Channel 1-4

        string += String(format:"%04X",Int(Code))
        
        //End of the message
        string +=  "\r\n"
        
        //Log this message to the window
        self.receivedDataTextView.textStorage?.mutableString.append(string as String)
        self.receivedDataTextView.needsDisplay = true
        
        //Sets the text
        /*if let data = string.data(using: String.Encoding.utf8) {
         self.serialPort?.send(data)
         }
         */
        
        
    }
    
    
    @IBAction func BV2_set(_ sender: NSButtonCell) {
        
        BV2_text.title = BV2_input.title
        
        let input = Double(BV2_input.title)
        let Code = input!/DAC_ref * 65535
        //Creat message string
        var string = ""
        
        //Formating the Message
        string += "D"  //DAC Identified
        string += "1"  //DAC ID 1-3
        string += "2"  //Channel 1-4
        
        string += String(format:"%04X",Int(Code))
        
        //End of the message
        string +=  "\r\n"
        
        //Log this message to the window
        self.receivedDataTextView.textStorage?.mutableString.append(string as String)
        self.receivedDataTextView.needsDisplay = true
        
        //Sets the text
        /*if let data = string.data(using: String.Encoding.utf8) {
         self.serialPort?.send(data)
         }
         */

        
    }
    
    //Bias Voltage End
 
    //Bias Current  Start
    
    @IBAction func BC1_set(_ sender: NSButtonCell) {
        
        
        let input = Double(BC1_input.title)
        let voltage = input! * (0.000001) * 200 * (4.99 + 45.3)/4.99
        
        let Code = voltage/DAC_ref * 65535.0

        //Creat message string
        var string = ""
        
        //Formating the Message
        string += "D"  //DAC Identified
        string += "1"  //DAC ID 1-3
        string += "1"  //Channel 2
        string += String(format:"%04X",Int(Code))
        
        //End of the message
        string +=  "\r\n"
        
        //Log this message to the window
        self.receivedDataTextView.textStorage?.mutableString.append(string as String)
        self.receivedDataTextView.needsDisplay = true
        
        //Sets the text
        /*if let data = string.data(using: String.Encoding.utf8) {
         self.serialPort?.send(data)
         }
         */
    }
    
    
    @IBAction func BC2_set(_ sender: NSButtonCell) {
        let input = Double(BC2_input.title)
        let voltage = input! * (0.000001) * 200 * (4.99 + 45.3)/4.99
        
        let Code = voltage/DAC_ref * 65535.0
        
        //Creat message string
        var string = ""
        
        //Formating the Message
        string += "D"  //DAC Identified
        string += "1"  //DAC ID 1-3
        string += "2"  //Channel 2
        string += String(format:"%04X",Int(Code))
        
        //End of the message
        string +=  "\r\n"
        
        //Log this message to the window
        self.receivedDataTextView.textStorage?.mutableString.append(string as String)
        self.receivedDataTextView.needsDisplay = true
        
        //Sets the text
        /*if let data = string.data(using: String.Encoding.utf8) {
         self.serialPort?.send(data)
         }
         */

    }

    
    
    //Bias Current End
    
    
    @IBOutlet weak var Bitrate: NSPopUpButtonCell!
    
    @IBOutlet weak var Polarity: NSMatrix!
    
  /*  @IBOutlet weak var P1_current: NSTextFieldCell!
    
    @IBAction func P1_set(_ sender: NSButtonCell) {
        //P1_current.title = String(Polarity.selectedRow)
        P1_current.title = Bitrate.title
        
    }
 */
    
}
